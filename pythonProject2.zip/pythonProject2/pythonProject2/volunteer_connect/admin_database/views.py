from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from news.forms import NewsForm
from news.models import News
from events.models import Events




from django.contrib.auth.models import User

from accounts.models import Organizer,Volunteer


# Create your views here.
from django.db.models.functions import ExtractMonth, ExtractYear
from django.db.models import Count



from django.db.models.functions import TruncMonth
from django.db.models import Count
from django.utils import timezone


def administrator_page(request):
    current_date = timezone.now()

    volunteers_by_month = Volunteer.objects.annotate(
        year=ExtractYear('user__date_joined'),
        month=ExtractMonth('user__date_joined')
    ).values('year', 'month').annotate(count=Count('id')).order_by('year', 'month').distinct()

    years = Volunteer.objects.dates('user__date_joined', 'year', order='DESC').distinct()
    months = Volunteer.objects.dates('user__date_joined', 'month', order='DESC').distinct()

    organizers_by_month = Organizer.objects.annotate(
        year=ExtractYear('user__date_joined'),
        month=ExtractMonth('user__date_joined')
    ).values('year', 'month').annotate(count=Count('id')).order_by('year', 'month').distinct()

    organizers_years = Organizer.objects.dates('user__date_joined', 'year', order='DESC').distinct()
    organizers_months = Organizer.objects.dates('user__date_joined', 'month', order='DESC').distinct()

    if request.method == 'POST':
        organizers_year = request.POST.get('year')
        organizers_month = request.POST.get('month')
        if organizers_year and organizers_month:
            organizers_by_month = Organizer.objects.filter(
                user__date_joined__year=organizers_year,
                user__date_joined__month=organizers_month
            ).annotate(
                year=ExtractYear('user__date_joined'),
                month=ExtractMonth('user__date_joined')
            ).values('year', 'month').annotate(count=Count('id')).order_by('year', 'month').distinct()

    if request.method == 'POST':
        year = request.POST.get('year')
        month = request.POST.get('month')
        if year and month:
            volunteers_by_month = Volunteer.objects.filter(
                user__date_joined__year=year,
                user__date_joined__month=month
            ).annotate(
                year=ExtractYear('user__date_joined'),
                month=ExtractMonth('user__date_joined')
            ).values('year', 'month').annotate(count=Count('id')).order_by('year', 'month').distinct()

    return render(request, 'admin_database/admin_profile.html',
                  {'volunteers_by_month': volunteers_by_month, 'current_date': current_date, 'years': years,
                   'months': months, 'organizers_by_month': organizers_by_month, 'organizers_years': organizers_years, 'organizers_months': organizers_months})




def other_page(request):
    events = Events.objects.filter(user=request.user)
    # Ваш код для другой страницы
    return render(request, 'admin_database/events.html', {'events': events})




def volunteers_admin_page(request):
    volunteers = User.objects.filter(groups__name='Volunteer')
    return render(request, 'admin_database/volunteers.html', {'volunteers': volunteers})

def volunteer_detail_page(request, volunteer_id):
    user = User.objects.get(id=volunteer_id)

    return render(request, 'admin_database/change_group.html', {'user': user})


def volunteer_edit_page(request, volunteer_id):
    volunteer = Volunteer.objects.get(user_id=volunteer_id)
    user = volunteer.user

    if request.method == 'POST':
        volunteer_form = VolunteerForm(request.POST, request.FILES, instance=volunteer)
        user_form = UserForm(request.POST, instance=user)
        if volunteer_form.is_valid() and user_form.is_valid():
            volunteer_form.save()
            user_form.save()
            return redirect('volunteer_detail_page', volunteer_id=volunteer_id)
    else:
        volunteer_form = VolunteerForm(instance=volunteer)
        user_form = UserForm(instance=user)

    context = {
        'volunteer_form': volunteer_form,
        'user_form': user_form,
    }

    return render(request, 'admin_database/volunteer_edit.html', context)

from django.contrib import messages




def organizator_admin_page(request):
    organizations = User.objects.filter(groups__name='Organizer')
    # Ваш код для другой страницы
    return render(request, 'admin_database/organizator.html', {'organizations': organizations})

def news_admin_page(request):
    total_applications = News.objects.count()
    new = News.objects.all()
    # Ваш код для другой страницы
    return render(request, 'admin_database/news_page.html', {'total_applications': total_applications, 'new': new})




# Блокирование новостей
from django.shortcuts import redirect

from django.http import JsonResponse

from django.contrib.admin.views.decorators import staff_member_required

@staff_member_required
def change_status(request, event_id):
    event = Events.objects.get(id=event_id)
    if request.method == 'POST':
        status = request.POST.get('status')
        event.status = status
        if status == '2':  # Если статус равен 'Отклонено'
            reason = request.POST.get('reason')
            event.reason = reason
        event.save()
        return redirect('administrator_page')

    return redirect('administrator_page')


def view_all_comments(request, news_id):
    news = get_object_or_404(News, id=news_id)
    comments = Comment.objects.filter(news=news)
    volunteers = Volunteer.objects.all()  # Получаем все объекты Volunteer
    return render(request, 'admin_database/view_comments.html', {'news': news, 'comments': comments, 'volunteers': volunteers})


def update_comment_status(request , comment_id):
    comment = get_object_or_404(Comment , id=comment_id)

    if request.method == 'POST':
        status = request.POST.get('status')
        comment.status = status
        comment.save()

    return redirect('view_all_comments' , news_id=comment.news.id)


from django.contrib.auth.forms import PasswordChangeForm

def change_password(request, user_id):
    user = User.objects.get(id=user_id)
    if request.method == 'POST':
        form = PasswordChangeForm(user=user, data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('volunteer_detail', user_id=user_id)
    else:
        form = PasswordChangeForm(user=user)
    return render(request, 'admin_database/change_password.html', {'form': form})



