
from django.urls import path

from . import views

urlpatterns = [
    path('administrator_page/', views.administrator_page, name='administrator_page'),
    path('view_all_comments/<int:news_id>/' , views.view_all_comments , name='view_all_comments') ,
    path('update_comment_status/<int:comment_id>/' , views.update_comment_status , name='update_comment_status') ,

    path('administrator_page/other_page/', views.other_page, name='other_page'),
    path('administrator_page/news_admin_page/', views.news_admin_page, name='news_admin_page'),

    path('administrator_page/volunteers_admin_page/', views.volunteers_admin_page, name='volunteers_admin_page'),
    path('administrator_page/organizator_admin_page/', views.organizator_admin_page, name='organizator_admin_page'),



    path('administrator_page/<int:volunteer_id>/' , views.volunteer_detail_page , name='volunteer_detail_page') ,
    path('administrator_page/edit/<int:volunteer_id>/', views.volunteer_edit_page, name='volunteer_edit_page'),



]