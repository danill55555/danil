from django.urls import path
from . import views





urlpatterns = [
    path('', views.news, name='news'),
    path('news_page/<int:news_page_id>/', views.news_page, name='news_page'),
    path('delete_comment/<int:comment_id>/', views.delete_comment, name='delete_comment'),

]