from django import forms
from .models import News


class NewsForm(forms.ModelForm):
    title = forms.CharField(
        label='Название' ,
        widget=forms.TextInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}) ,
        min_length=30
    )
    description = forms.CharField(
        label='Описание' ,
        widget=forms.Textarea(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}) ,
        min_length=100
    )

    class Meta:
        model = News
        fields = ['title' , 'description' , 'img']
        labels = {
            'title': 'Название' ,
            'description': 'Описание' ,
            'img': 'Изображение' ,
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}) ,
            'description': forms.Textarea(
                attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}) ,
            'img': forms.ClearableFileInput(
                attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}) ,
        }


class CommentForm(forms.Form):
    message = forms.CharField(label='Сообщение', widget=forms.Textarea(attrs={
        'placeholder': 'Текст',
        'class': 'block w-full px-4 py-4 my-2 leading-tight text-gray-700 bg-gray-100 border rounded dark:placeholder-gray-500 dark:text-gray-400 dark:border-gray-800 dark:bg-gray-800',
        'style': 'height: 160px;'
    }))
    rating = forms.IntegerField(label='Рейтинг', widget=forms.HiddenInput())

