from django.contrib.auth.models import User
from django.db import models

from django.dispatch import receiver
from django.db.models.signals import post_save
import requests


# Ваша модель News
class News(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField('Название', max_length=255)
    description = models.TextField('Описание')
    date = models.DateTimeField('Дата публикации', auto_now_add=True)
    img = models.ImageField(upload_to='news')
    blocked = models.BooleanField('Заблокирована', default=False)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Новость'
        verbose_name_plural = 'Новости'

def send_telegram_message(message):
    token = '5417219970:AAFzzrLZueDtOpD3RFZNT1AYsJf1mUmZhIE'
    chat_id = '1779736437'
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    data = {'chat_id': chat_id, 'text': message}
    response = requests.post(url, data=data)
    print(response.json())

@receiver(post_save, sender=News)
def news_post_save(sender, instance, **kwargs):
    if kwargs.get('created', False):
        message = f'Дата: {instance.date}\nНовая новость: {instance.title}\nОписание: {instance.description}'
        send_telegram_message(message)








class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    news = models.ForeignKey(News, on_delete=models.CASCADE)
    date_published = models.DateTimeField(auto_now_add=True)
    message = models.TextField()
    rating = models.IntegerField('Рейтинг', default=0)  # Добавляем поле рейтинга
    is_deleted = models.BooleanField(default=False)
    STATUS_CHOICES = (
        ('0', 'На рассмотрении'),
        ('1', 'Одобрено'),
        ('2', 'Отклонено'),
    )
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='0')

    def __str__(self):
        return f'{self.user.username} '

    class Meta:
        verbose_name = 'Комментарии'
        verbose_name_plural = 'Коментарий'