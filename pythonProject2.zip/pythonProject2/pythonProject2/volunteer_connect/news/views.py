from django.shortcuts import render

# Create your views here.
from django.conf import settings
from django.contrib import messages
from django.db.models import Count
from django.shortcuts import render, redirect, get_object_or_404

from .forms import CommentForm
from .models import News, Comment
from admin_database.models import ForbiddenWord


# from mainapp.models import UserProfile


# Create your views here.
def news(request):
    sort_param = request.GET.get('sort')
    if sort_param == 'newest':
        news = News.objects.order_by('-date')
    elif sort_param == 'oldest':
        news = News.objects.order_by('date')
    else:
        news = News.objects.all()
    return render(request, 'news/news.html', {'news': news, 'sort_param': sort_param})


def news_page(request, news_page_id):
    news_page = News.objects.get(id=news_page_id)
    news_comment = Comment.objects.filter(news=news_page, status='0',
                                          is_deleted=False)  # Получаем только одобренные комментарии

    total_comments = news_comment.count()

    total_rating = 0

    one_star_count = 0
    two_star_count = 0
    three_star_count = 0
    four_star_count = 0
    five_star_count = 0

    for comment in news_comment:
        total_rating += comment.rating
        if comment.rating == 1:
            one_star_count += 1
        elif comment.rating == 2:
            two_star_count += 1
        elif comment.rating == 3:
            three_star_count += 1
        elif comment.rating == 4:
            four_star_count += 1
        elif comment.rating == 5:
            five_star_count += 1

    if total_comments > 0:
        average_rating = round(total_rating / total_comments, 1)
    else:
        average_rating = 0

    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            message = form.cleaned_data['message']
            rating = form.cleaned_data['rating']
            user = request.user  # Предполагается, что у Вас есть авторизация пользователей

            if len(message) < 5:
                messages.error(request, 'Сообщение должно содержать не менее 5 символов')
                return redirect('news_page', news_page_id=news_page_id)

            if len(message) > 150:
                messages.error(request, 'Сообщение должно содержать не более 150 символов')
                return redirect('news_page', news_page_id=news_page_id)

            forbidden_words = ForbiddenWord.objects.all()
            for word in forbidden_words:
                if word.word in message:
                    messages.error(request, 'Ваш комментарий содержит запрещенные слова')
                    return redirect('news_page', news_page_id=news_page_id)

            comment = Comment.objects.create(user=user, news=news_page, message=message, rating=rating)
            comment.save()
            messages.success(request, 'Комментарий успешно добавлен')

            return redirect('news_page', news_page_id=news_page_id)
    else:
        form = CommentForm()

    context = {
        'news_page': news_page,
        'form': form,
        'news_comment': news_comment,
        'total_comments': total_comments,
        'average_rating': average_rating,
        'one_star_count': one_star_count,
        'two_star_count': two_star_count,
        'three_star_count': three_star_count,
        'four_star_count': four_star_count,
        'five_star_count': five_star_count
    }

    return render(request, 'news/news_page.html', context)


def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if comment.user == request.user:
        if request.method == 'POST':
            comment.is_deleted = True
            comment.save()
            messages.success(request, 'Ваш комментарий успешно удален')
            return redirect('news_page', news_page_id=comment.news.id)
    return redirect('news_page')



