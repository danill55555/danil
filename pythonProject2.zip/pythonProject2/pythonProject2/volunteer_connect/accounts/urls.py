from django.urls import path
from . import views


urlpatterns = [
    # Волонтер
    path('accounts/volunteer_register/', views.volunteer_register, name='volunteer_register'),
    path('volunteer_profile/', views.volunteer_profile, name='volunteer_profile'),
    path('edit-profile/', views.edit_profile, name='edit_profile'),
    # Организатор
    path('accounts/organizer_register/', views.organizer_register, name='organizer_register'),

    path('logout/', views.logout_view, name='logout'),
    # почта
    path('confirm_email/<uuid:token>/', views.confirm_email, name='confirm_email'),

    path('login/', views.login_view, name='login'),



    path('organization_profile/', views.organization_profile, name='organizations'),
    path('new_applications/', views.new_applications, name='new_applications'),

    path('all_events/', views.all_events, name='all_events'),
    path('submit_data/', views.submit_data, name='submit_data'),

]
