import datetime

from django.contrib.auth import logout, authenticate, login, update_session_auth_hash
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import render_to_string
from django.core.checks import messages
from .forms import UserForm, VolunteerForm, OrganizerForm, CustomLoginForm
from django.conf import settings
from django.contrib import messages
from .models import Volunteer, Organizer, OrganizationRole, VolunteerReview, OrganizerReview, VolunteerStats
from events.models import Events, Direction, Requests, Requests

from support_measures.models import Support, HelpType
from django.contrib.auth.decorators import login_required

# Create your views here.
# Регистрация Волонтера

def volunteer_register(request):

    if request.method == 'POST':
        user_form = UserForm(request.POST)
        volunteer_form = VolunteerForm(request.POST, request.FILES)
        if user_form.is_valid() and volunteer_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password'])
            user.save()

            volunteer = volunteer_form.save(commit=False)
            volunteer.user = user
            volunteer.save()

            # Генерация нового токена для подтверждения почты
            token = volunteer.email_confirmation_token

            subject = 'Подтверждение почты'
            message = render_to_string('accounts/email/email_confirmation.html', {'token': token})
            html_message = render_to_string('accounts/email/email_confirmation.html', {'token': token})
            from_email = settings.EMAIL_HOST_USER
            to_email = user.email
            send_mail(subject, message, from_email, [to_email], html_message=html_message)

            messages.success(request, 'Письмо для подтверждения почты отправлено. Пожалуйста, проверьте Вашу почту.')
    else:
        user_form = UserForm()
        volunteer_form = VolunteerForm()

    return render(request, 'accounts/volunteer_register.html', {'user_form': user_form, 'volunteer_form': volunteer_form})


# Регистрация Организации
def organizer_register(request):
    if request.method == 'POST':
        user_form = UserForm(request.POST)
        volunteer_form = VolunteerForm(request.POST, request.FILES)
        organizer_form = OrganizerForm(request.POST)

        if user_form.is_valid() and volunteer_form.is_valid() and organizer_form.is_valid():
            user = user_form.save()
            volunteer = volunteer_form.save(commit=False)
            volunteer.user = user
            volunteer.save()

            organizer = organizer_form.save(commit=False)
            organizer.user = user
            organizer.volunteer = volunteer
            organizer.save()

            # Генерация нового токена для подтверждения почты
            token = volunteer.email_confirmation_token

            subject = 'Подтверждение почты'
            message = render_to_string('accounts/email/email_confirmation.html', {'token': token})
            html_message = render_to_string('accounts/email/email_confirmation.html', {'token': token})
            from_email = settings.EMAIL_HOST_USER
            to_email = user.email
            send_mail(subject, message, from_email, [to_email], html_message=html_message)

            messages.success(request, 'Письмо для подтверждения почты отправлено. Пожалуйста, проверьте Вашу почту.')


    else:
        user_form = UserForm()
        volunteer_form = VolunteerForm()
        organizer_form = OrganizerForm()

    return render(request, 'accounts/organizer_register.html', {'user_form': user_form, 'volunteer_form': volunteer_form, 'organizer_form': organizer_form})


# Авторизация
def login_view(request):
    if request.method == 'POST':
        form = CustomLoginForm(request.POST)
        if form.is_valid():
            username_or_email = form.cleaned_data['username_or_email']
            password = form.cleaned_data['password']
            user = None

            if '@' in username_or_email:
                try:
                    user = User.objects.get(email=username_or_email)
                except User.DoesNotExist:
                    pass
            else:
                user = authenticate(username=username_or_email, password=password)

            if user is not None:
                if not user.check_password(password):
                    messages.error(request, "Invalid password")
                else:
                    if '@' in username_or_email:
                        try:
                            user_profile = Volunteer.objects.get(user=user)
                            if user_profile.email_confirmed:
                                login(request, user)
                                return redirect('mainapp:home')
                            else:
                                messages.error(request, "Email is not confirmed")
                        except Volunteer.DoesNotExist:
                            messages.error(request, "User profile not found")
                    else:
                        login(request, user)
                        return redirect('mainapp:home')
            else:
                messages.error(request, "Invalid login or password")

    else:
        form = CustomLoginForm()

    return render(request, 'accounts/login.html', {'form': form})

# Организация профиля


# мероприятия на странице организатора
def all_events(request):
    query = request.GET.get('q')
    country = request.GET.get('country')
    start_date = request.GET.get('start_date')
    directions = request.GET.getlist('direction')  # Получаем список выбранных направлений
    user = request.user
    events = Events.objects.filter(user=user)

    all_directions = Direction.objects.all()  # Получаем все направления из базы данных

    if query:
        events = events.filter(title__icontains=query)

    if country:
        events = events.filter(country__icontains=country)

    if start_date:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        events = events.filter(start_date__date=start_date)

    if directions:
        events = events.filter(directions__id__in=directions).distinct()  # Фильтруем события по выбранным направлениям

    return events, all_directions




def support_measures(request):
    user = request.user
    query = request.GET.get('q')
    date = request.GET.get('date')
    location = request.GET.get('location')
    supports = Support.objects.filter(user=user)
    help_types = HelpType.objects.all()  # Получаем все виды помощи

    if query:
        supports = supports.filter(name__icontains=query)

    if date:
        date = datetime.strptime(date, '%Y-%m-%d')
        supports = supports.filter(date=date)



    if location:
        supports = supports.filter(location__icontains=location)

    return supports, help_types


def update_volunteer_data(request, volunteer_id):
    volunteer = get_object_or_404(Volunteer, id=volunteer_id)

    if request.method == 'POST':
        hours_worked = int(request.POST.get('hours_worked'))
        rating = float(request.POST.get('rating'))

        volunteer.hours_worked += hours_worked
        volunteer.rating = (volunteer.rating + rating) / 2

        volunteer.save()

        return HttpResponse('Данные успешно обновлены')

    return HttpResponse('Метод не поддерживается')


# Заявки
def view_applications(request):
    user_requests = Requests.objects.all()
    events = Events.objects.filter(id__in=user_requests.values_list('event'))
    total_volunteers = user_requests.count()
    recruited_volunteers = user_requests.filter(status='Набрано').count()

    return user_requests, events, total_volunteers, recruited_volunteers




# def organization_employees(request):
#     # organizer = Organizer.objects.get(volunteer=request.user)
#     role_filter = request.GET.get('role_filter')
#
#     if role_filter == '0':
#         employees = OrganizationRole.objects.filter(organizer=organizer, role='0')
#     else:
#         employees = OrganizationRole.objects.filter(organizer=organizer)
#
#     return employees


def submit_data(request):
    if request.method == 'POST':
        hours_worked = request.POST.get('hours_worked')
        rating = request.POST.get('rating')
        request_id = request.POST.get('request_id')

        request_obj = Requests.objects.get(id=request_id)
        request_obj.user.profile.volunteer_profile.hours_worked += int(hours_worked)
        request_obj.user.profile.volunteer_profile.rating = float(rating)
        request_obj.user.profile.volunteer_profile.save()

        return HttpResponse('Данные успешно отправлены!')
    else:
        return HttpResponse('Метод не разрешен')
def reviews_organizations(request):
    organizer_reviews = Organizer.objects.filter(user=request.user)
    organizer_comments = VolunteerReview.objects.filter(organizer=request.user)
    reviews = OrganizerReview.objects.filter(organizer__in=organizer_reviews)



    return organizer_reviews, reviews, organizer_comments



def organization_profile(request):
    events_data, all_directions = all_events(request)
    user_requests, events, total_volunteers, recruited_volunteers = view_applications(request)
    supports, help_types = support_measures(request)
    # employees, organizer = organization_employees(request)
    organizer_reviews, reviews, organizer_comments = reviews_organizations(request)


    context = {
        'events_data': events_data,
        'all_directions': all_directions,
        'user_requests': user_requests,
        'events': events,
        'total_volunteers': total_volunteers,
        'recruited_volunteers': recruited_volunteers,
        'supports': supports,
        'help_types': help_types,
        # 'employees': employees,
        # 'organizer': organizer,
        'organizer_reviews': organizer_reviews,
        'reviews': reviews,
        'organizer_comments': organizer_comments

    }

    return render(request, 'accounts/organizations/organization_profile.html', context)



def logout_view(request):
    logout(request)
    return redirect('mainapp:home')



from django.http import HttpResponse

def confirm_email(request, token):
    try:
        volunteer = Volunteer.objects.get(email_confirmation_token=token)
        volunteer.email_confirmed = True
        volunteer.save()
        return HttpResponse("Email успешно подтвержден!")
    except Volunteer.DoesNotExist:
        return HttpResponse("Неверный токен для подтверждения email.")


def new_applications(request):
    events = Events.objects.all()

    event_requests = {}

    for event in events:
        requests_for_event = Requests.objects.filter(event=event)
        if requests_for_event.exists():
            event_requests[event] = requests_for_event

    if request.method == 'POST':
        selected_volunteers = request.POST.getlist('volunteer_checkbox')
        if 'select_all' in request.POST:
            selected_volunteers = [str(request.user.volunteer.id)]

        for volunteer_id in selected_volunteers:
            volunteer = Volunteer.objects.get(id=volunteer_id)
            hours = request.POST.get(f'hours_{volunteer_id}')
            rating = request.POST.get(f'rating_{volunteer_id}')

            stats, created = VolunteerStats.objects.get_or_create(volunteer=volunteer)
            stats.volunteer_hours = hours
            stats.rating = rating
            stats.save()

    context = {
        'event_requests': event_requests,
    }

    return render(request, 'accounts/organizations/new_applications.html', context)

# волонтер профиль

def volunteer_profile(request):
    user = request.user
    volunteer = request.user.volunteer
    applications = Requests.objects.filter(user=user)[:3]

    return render(request, 'accounts/volunteers/profile.html',
                  {'volunteer': volunteer, 'applications': applications})


def edit_profile(request):
    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=request.user)
        user_profile_form = VolunteerForm(request.POST, instance=request.user.profile)
        user_volunteer_form = VolunteerForm(request.POST, instance=request.user.profile.volunteer)
        if user_form.is_valid() and user_profile_form.is_valid() and user_volunteer_form.is_valid():
            user = user_form.save(commit=False)
            password = user_form.cleaned_data.get('password')
            if password:
                user.set_password(password)  # использование set_password вместо make_password
                update_session_auth_hash(request, user)  # обновление хэша аутентификации в текущей сессии
            user.save()
            user_profile_form.save()
            user_volunteer_form.save()
            return redirect('profile')
    else:
        user_form = UserForm(instance=request.user)
        user_profile_form = VolunteerForm(instance=request.user.volunteer)


    context = {
        'user_form': user_form,
        'user_profile_form': user_profile_form,

    }
    return render(request, 'accounts/volunteers/edit_profile.html', context)


