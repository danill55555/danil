from django.contrib import admin

# Register your models here.
from .models import Volunteer, VolunteerStats, Organizer, OrganizationRole, OrganizerReview, VolunteerReview

admin.site.register(Volunteer)

admin.site.register(VolunteerStats)

admin.site.register(Organizer)

admin.site.register(OrganizationRole)

admin.site.register(OrganizerReview)

admin.site.register(VolunteerReview)