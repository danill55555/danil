from django import forms
from django.contrib.auth.models import User
from django.forms import DateInput

from .models import Volunteer, Organizer


class UserForm(forms.ModelForm):
    password_confirm = forms.CharField(label='Confirm Password', widget=forms.PasswordInput(attrs={
        'class': 'p-2 block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
        'placeholder': 'Подтверждение почты'}))

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password', 'password_confirm']
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'p-2 block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Логин',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'p-2 block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Электронная почта'}),
            'password': forms.PasswordInput(attrs={
                'class': 'p-2 block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Пароль'}),
            'first_name': forms.TextInput(attrs={
                'class': 'p-2 block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Имя'}),
            'last_name': forms.TextInput(attrs={
                'class': 'p-2 block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Фамилия'}),
        }

        def clean(self):
            cleaned_data = super().clean()
            username = cleaned_data.get('username')
            first_name = cleaned_data.get('first_name')
            last_name = cleaned_data.get('last_name')
            email = cleaned_data.get('email')
            password = cleaned_data.get('password')
            password_confirm = cleaned_data.get('password_confirm')



class VolunteerForm(forms.ModelForm):
    consent_personal_data = forms.BooleanField(label='Согласен на обработку персональных данных', required=True,
                                               widget=forms.CheckboxInput(attrs={
                                                   'class': 'form-check-input w-5', 'id': 'id_consent_personal_data'
                                               }))
    date_of_birth = forms.DateField(label='Дата рождения', widget=DateInput(attrs={
        'type': 'date',
        'class': 'p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700',
        'placeholder': 'Дата рождения'
    }))

    class Meta:
        model = Volunteer
        fields = ['patronymic', 'country', 'city', 'date_of_birth', 'photo', 'phone', 'consent_personal_data']
        widgets = {
            'patronymic': forms.TextInput(attrs={
                'class': 'p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Иванович'}),
            'phone': forms.TextInput(attrs={
                'class': 'p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Телефон', 'id': 'id_phone', 'oninput': 'maskPhone(event)'}),
            'address': forms.TextInput(attrs={
                'class': 'p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'г.Москва; п.г.т Джалиль; и т.д'}),
            'photo': forms.FileInput(attrs={
                'class': ' p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Фотография'}),
            'city': forms.TextInput(attrs={
                'class': 'p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'г.Москва; п.г.т Джалиль; и т.д'}),
            'country': forms.TextInput(attrs={
                'class': 'p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40',
                'placeholder': 'Россия; и т.д'}),

        }

        def clean(self):
            cleaned_data = super().clean()
            phone = cleaned_data.get('phone')
            address = cleaned_data.get('address')
            patronymic = cleaned_data.get('patronymic')
            photo = cleaned_data.get('photo')
            date_of_birth = cleaned_data.get('date_of_birth')


class OrganizerForm(forms.ModelForm):
    organization_name = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'p-2 text-md block w-full px-5 py-1 mt-2 text-gray-700 placeholder-gray-400'
            ' bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 '
            'dark:border-gray-700 ', 'placeholder': 'Название организации'})
    )
    class Meta:
        model = Organizer
        fields = ['organization_name']




class CustomLoginForm(forms.Form):
    username_or_email = forms.CharField(label='Логин или почта', widget=forms.TextInput(attrs={'class': 'border rounded-md p-2 mb-4'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'border rounded-md p-2'}), label='Пароль')

