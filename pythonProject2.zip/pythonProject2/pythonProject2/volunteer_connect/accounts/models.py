from datetime import date

from django.db import models
from django.contrib.auth.models import User

import uuid


# Волонтер
class Volunteer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    patronymic = models.CharField(max_length=255)
    country = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    photo = models.ImageField(upload_to='volunteer/')
    phone = models.CharField(max_length=20)
    about = models.TextField()
    education = models.CharField(max_length=100)
    languages = models.CharField(max_length=100)
    volunteer_id = models.CharField(max_length=50)
    workplace = models.CharField(max_length=255)
    email_confirmed = models.BooleanField(default=False)
    email_confirmation_token = models.UUIDField(default=uuid.uuid4, editable=False)

    def get_age(self):
        today = date.today()
        age = today.year - self.date_of_birth.year - (
                    (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day))
        return age

    def __str__(self):
        return self.user.username


class VolunteerStats(models.Model):
    volunteer = models.OneToOneField(Volunteer, on_delete=models.CASCADE)
    rating = models.IntegerField(default=0)
    events_completed = models.IntegerField(default=0)
    volunteer_hours = models.IntegerField(default=0)

    def __str__(self):
        return f"Stats for {self.volunteer.user.username}"



# Организатор
class Organizer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    organization_name = models.CharField(max_length=255)
    volunteer = models.OneToOneField(Volunteer, on_delete=models.CASCADE, related_name='organizer')

    def __str__(self):
        return self.user.username

    def get_employees(self):
        return OrganizationRole.objects.filter(organizer=self).select_related('user_profile')

    class Meta:
        verbose_name = 'Организатор'
        verbose_name_plural = 'Организаторы'


class OrganizationRole(models.Model):
    ROLE_CHOICES = (
        ('0', 'Суперпользователь'),
        ('1', 'Волонтер'),
        ('2', 'Организатор'),
        # Добавьте другие роли по Вашему усмотрению
    )
    organizer = models.ForeignKey(Organizer, on_delete=models.CASCADE, related_name='roles')
    role = models.CharField(max_length=1, choices=ROLE_CHOICES)

    def __str__(self):
        return f"{self.role}"

    class Meta:
        verbose_name = 'Роль'
        verbose_name_plural = 'Роли'


class OrganizerReview(models.Model):
    reviewer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews_organizer')
    organizer = models.ForeignKey('Organizer', on_delete=models.CASCADE, related_name='reviews_received')
    rating = models.IntegerField()
    comment = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Review for {self.organizer.user_profile.user.username} by {self.reviewer.username}"

    class Meta:
        verbose_name = 'Review for Organizer'
        verbose_name_plural = 'Reviews for Organizers'



class VolunteerReview(models.Model):
    organizer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments_organizer')
    volunteer = models.ForeignKey(Volunteer, on_delete=models.CASCADE, related_name='reviews_received')
    rating = models.IntegerField()
    comment = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)




    class Meta:
        verbose_name = 'Review for Volunteer'
        verbose_name_plural = 'Reviews for Volunteers'