from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class HelpType(models.Model):
    name = models.CharField(max_length=100)


class Support(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    location = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='images/')
    date = models.DateField()
    help_type = models.ForeignKey(HelpType, on_delete=models.CASCADE)
    STATUS_CHOICES = (
        ('0', 'Рассматривается'),
        ('1', 'Принято'),
        ('2', 'Отклонено'),
        ('3', 'Завершено')
    )
    status = models.CharField('Статус', max_length=1, choices=STATUS_CHOICES)

    def __str__(self):
        return self.name