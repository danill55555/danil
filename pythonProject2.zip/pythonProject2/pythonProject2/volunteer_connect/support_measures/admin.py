from django.contrib import admin

# Register your models here.
from .models import Support, HelpType

admin.site.register(Support)

admin.site.register(HelpType)

