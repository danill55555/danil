from django.contrib.auth import logout
from django.shortcuts import render, redirect

from news.models import News


# Create your views here.
# Главная страница
def index(request):
    news = News.objects.filter(blocked=False).order_by('-id')[:5]


    return render(request, 'mainapp/index.html', { 'news': news})


