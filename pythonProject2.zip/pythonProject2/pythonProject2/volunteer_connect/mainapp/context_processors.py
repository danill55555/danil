def add_user_groups(request):
    is_volunteer = request.user.groups.filter(name='Volunteer').exists()
    is_organizer = request.user.groups.filter(name='Organizer').exists()
    is_administrator = request.user.groups.filter(name='Administrator').exists()
    return {
        'is_organizer': is_organizer,
        'is_volunteer': is_volunteer,
        'is_administrator': is_administrator
    }