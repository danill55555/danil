from django.urls import path
from . import views
from admin_database.views import administrator_page

app_name = "mainapp"

urlpatterns = [
    path('', views.index, name='home'),
    path('administrator_page/', administrator_page, name='administrator_page'),


]