from django.urls import path
from . import views

urlpatterns = [
    path('', views.events, name='events'),
    path('events_page/<int:events_page_id>/', views.events_page, name='events_page'),

]