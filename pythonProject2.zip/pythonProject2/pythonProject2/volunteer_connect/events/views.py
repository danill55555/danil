from django.shortcuts import render, redirect
import json
from django.contrib import messages

from .forms import EventFilterForm
from .models import Events, Requests


# Create your views here.
def events(request):
    query = request.GET.get('q')
    events = Events.objects.all()
    sort_param = request.GET.get('sort')
    events_json = json.dumps(list(events.values('latitude', 'longitude', 'title', 'description')))

    if query:
        events = events.filter(title__icontains=query)


    if sort_param == 'eventest':
        events = Events.objects.order_by('-publication_date')
    elif sort_param == 'oldest':
        events = Events.objects.order_by('publication_date')
    else:
        events = Events.objects.all()



    if request.method == 'GET':
        form = EventFilterForm(request.GET)
        if form.is_valid():
            online = form.cleaned_data['online']
            offline = form.cleaned_data['offline']
            conditions = form.cleaned_data['conditions']
            directions = form.cleaned_data['directions']
            start_date = form.cleaned_data['start_date']
            country = form.cleaned_data['country']

            if online and offline:
                events = Events.objects.all()
            elif online:
                events = events.filter(category__name='Онлайн')
            elif offline:
                events = events.filter(category__name='Офлайн')

            if conditions:
                events = events.filter(conditions__in=conditions)

            if directions:
                events = events.filter(directions__in=directions)

            if start_date:
                events = events.filter(start_date__date__gte=start_date)

            if country:
                events = events.filter(location__city__icontains=country)

            events = events.distinct()

    else:
        form = EventFilterForm()

    return render(request, 'events/events.html', {'events_json': events_json , 'form': form, 'events': events, 'sort_param': sort_param})


def events_page(request, events_page_id):
    event = Events.objects.get(id=events_page_id)
    events_json = json.dumps([{
        'latitude': event.latitude,
        'longitude': event.longitude,
        'title': event.title,
        'description': event.description
    }])

    confirmed_applications_count = Requests.objects.filter(event=event, status='1').count()
    tasks_list = event.tasks.split("\n")
    directions_list = [directions.name for directions in event.directions.all()]  # Получение списка направлений
    display_directions = ', '.join(directions_list)  # Преобразование списка в строку с разделителем ", "
    if request.method == 'POST':
        event_id = request.POST.get('event_id')

        request_instance = Requests(user=request.user, event=event)

        existing_application = Requests.objects.filter(user=request.user, event_id=event_id).exists()

        if not existing_application:

            request_instance.status = '0'  # Устанавливаем статус "Рассматривается"
            request_instance.save()
            messages.success(request, 'Заявка успешно отправлена')

        return redirect('events_page', events_page_id=event_id)

    return render(request, 'events/events_page.html', {'event': event, 'events_json': events_json, 'tasks_list': tasks_list, 'display_directions': display_directions, 'confirmed_applications_count': confirmed_applications_count})

