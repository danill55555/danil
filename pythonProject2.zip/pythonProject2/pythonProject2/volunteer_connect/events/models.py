
from django.db import models
from django.contrib.auth.models import User
import geocoder
from django.dispatch import receiver
from django.db.models.signals import post_save
import requests
# Create your models here.

class Condition(models.Model):
    name = models.CharField('Название', max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Условия'
        verbose_name_plural = 'Условия'


class Category(models.Model):
    name = models.CharField('Категория', max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'


from django.db import models


class Direction(models.Model):
    name = models.CharField(max_length=255)


    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Направление'
        verbose_name_plural = 'Направления'


class Events(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField('Название', max_length=255)
    description = models.TextField('Описание')
    publication_date = models.DateTimeField('Дата публикации', auto_now_add=True)
    start_date = models.DateTimeField('Дата начала мероприятия')
    end_date = models.DateTimeField('Дата окончания мероприятия')
    img = models.ImageField(upload_to='events/img')
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    conditions = models.ManyToManyField(Condition, blank=True)
    volunteers = models.IntegerField('Количество волонтеров')
    blocked = models.BooleanField('Заблокирована', default=False)
    directions = models.ManyToManyField(Direction, blank=True)

    tasks = models.TextField('Задачи для волонтеров')
    reason = models.TextField('Причина отклонения', blank=True)

    country = models.CharField(max_length=100, null=True)
    latitude = models.FloatField(default=0)
    longitude = models.FloatField(default=0)
    population = models.PositiveIntegerField(null=True)

    STATUS_CHOICES = (
        ('0', 'Ожидает подтверждения'),
        ('1', 'Одобрено'),
        ('2', 'Отклонено'),
    )

    status = models.CharField('Статус', max_length=10, choices=STATUS_CHOICES)

    def __str__(self):
        return self.title

    def get_duration(self):
        duration = self.end_date - self.start_date
        return duration.days + 1

    def save(self, *args, **kwargs):
        self.latitude = geocoder.osm(self.country).lat
        self.longitude = geocoder.osm(self.country).lng
        return super().save(*args, **kwargs)


    class Meta:
        verbose_name = 'Мероприятие'
        verbose_name_plural = 'Мероприятия'


def send_telegram_message(message):
    token = '5417219970:AAFzzrLZueDtOpD3RFZNT1AYsJf1mUmZhIE'
    chat_id = '1779736437'
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    data = {'chat_id': chat_id, 'text': message}
    response = requests.post(url, data=data)
    print(response.json())

@receiver(post_save, sender=Events)
def news_post_save(sender, instance, **kwargs):
    if kwargs.get('created', False):
        message = f'Дата: {instance.publication_date}\nНовая мероприятия: {instance.title}\nОписание: {instance.description}'
        send_telegram_message(message)

class Requests(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Пользователь')
    event = models.ForeignKey(Events, on_delete=models.CASCADE, related_name='event_requests')
    STATUS_CHOICES = (
        ('0', 'Рассматривается'),
        ('1', 'Принято'),
        ('2', 'Отклонено'),
    )
    status = models.CharField('Статус', max_length=1, choices=STATUS_CHOICES)

    def __str__(self):
        return f'{self.user.username} '

    class Meta:
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'
