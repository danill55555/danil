from django import forms
from .models import Events, Condition, Direction

class EventFilterForm(forms.Form):
    online = forms.BooleanField(required=False, initial=True, widget=forms.CheckboxInput(attrs={'class': 'form-checkbox'}))
    offline = forms.BooleanField(required=False, initial=True, widget=forms.CheckboxInput(attrs={'class': 'form-checkbox'}))
    conditions = forms.ModelMultipleChoiceField(queryset=Condition.objects.all(), required=False, widget=forms.CheckboxSelectMultiple(attrs={'class': 'form-checkbox'}))
    start_date = forms.DateField(required=False, widget=forms.DateInput(attrs={'class': 'form-input'}))
    directions = forms.ModelMultipleChoiceField(queryset=Direction.objects.all(), required=False, widget=forms.CheckboxSelectMultiple(attrs={'class': 'form-checkbox'}))
    country = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-input'}))

class EventForm(forms.ModelForm):
    title = forms.CharField(
        label='Название',
        widget=forms.TextInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}),
        min_length=30
    )
    description = forms.CharField(
        label='Описание',
        widget=forms.Textarea(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}),
        min_length=100
    )
    country = forms.CharField(
        label='Город',
        widget=forms.TextInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'})
    )


    class Meta:
        model = Events
        fields = ['title', 'description', 'img', 'category', 'conditions', 'country', 'volunteers', 'directions', 'start_date', 'end_date', 'tasks']
        labels = {
            'title': 'Название',
            'description': 'Описание',
            'img': 'Изображение',
            'category': 'Категория',
            'conditions': 'Условия',
            'country': 'Город',
            'volunteers': 'Количество волонтеров',
            'directions': 'Направление',
            'start_date': 'Дата начала',
            'end_date': 'Дата окончания',
            'tasks': 'Задачи для волонтеров',
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}),
            'description': forms.Textarea(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}),
            'img': forms.ClearableFileInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}),
            'category': forms.Select(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full'}),
            'conditions': forms.CheckboxSelectMultiple(attrs={'class': 'list-none mb-2'}),
            'directions': forms.CheckboxSelectMultiple(attrs={'class': 'list-none mb-2'}),
            'volunteers': forms.NumberInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-2 w-full'}),
            'tasks': forms.Textarea(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-2 w-full'}),
            'start_date': forms.DateInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full', 'placeholder': 'YYYY-MM-DD'}),
            'end_date': forms.DateInput(attrs={'class': 'border border-gray-300 rounded-md py-2 px-3 mt-1 mb-4 w-full', 'placeholder': 'YYYY-MM-DD'}),
        }

    def clean_img(self):
        img = self.cleaned_data.get('img')
        if img:
            if img.size > 1024 * 1024:  # 1MB
                raise forms.ValidationError("Размер изображения должен быть не более 1MB.")
        return img

    def clean(self):
        cleaned_data = super().clean()
        conditions = cleaned_data.get('conditions')
        if not conditions:
            raise forms.ValidationError('Выберите хотя бы одно условие.')
