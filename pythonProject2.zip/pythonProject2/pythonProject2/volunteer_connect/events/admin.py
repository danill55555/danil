from django.contrib import admin
from .models import Events, Category, Condition, Direction, Requests

# Register your models here.
admin.site.register(Events)

admin.site.register(Category)

admin.site.register(Condition)


admin.site.register(Direction)

admin.site.register(Requests)